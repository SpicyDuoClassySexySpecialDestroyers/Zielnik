# Zielnik — Android prototype

Pierwsza wersja projektu natywnej aplikacji Android w Javie (bez zewnętrznych bibliotek UI).

## Funkcje
- lokalny zapis zadań w SharedPreferences;
- dodawanie i edycja tytułu oraz opcjonalnego opisu;
- przytrzymanie karty otwiera menu Edytuj / Usuń;
- usunięcie wymaga potwierdzenia;
- oznaczenie jako wykonane usuwa zadanie i jego powiadomienie;
- osobne powiadomienie `ongoing` dla każdego zadania;
- przywracanie powiadomień po restarcie telefonu;
- zielony, minimalistyczny interfejs.

## Budowanie APK bez Android Studio

Projekt zawiera workflow GitHub Actions: `.github/workflows/build-apk.yml`.
1. Utwórz prywatne repozytorium na GitHubie.
2. Wgraj do niego zawartość tego folderu.
3. Otwórz zakładkę **Actions** i uruchom workflow **Build Zielnik APK**.
4. Po zakończeniu pobierz artefakt `zielnik-debug-apk` — zawiera `app-debug.apk`.

Wymagania kompilacji: JDK 17, Gradle 8.11.1, Android SDK Platform 36 i Build Tools (instalowane przez workflow).

## Ważne ograniczenia prototypu
- Android / HyperOS mogą nadal zatrzymać aplikację, wyłączyć jej powiadomienia lub ograniczyć działanie w tle. `ongoing` blokuje zwykłe przesunięcie powiadomienia, ale nie daje absolutnej odporności na działania systemu.
- Usługa używa typu foreground service `specialUse`. To uzasadnienie wymaga weryfikacji względem zasad Google Play, jeśli aplikacja miałaby być publikowana w sklepie. Projekt jest na razie przeznaczony do prywatnych testów APK.
- Powiadomienia i działanie po restarcie należy przetestować na docelowym Redmi 15 / HyperOS 3. Ten projekt nie był jeszcze skompilowany ani przetestowany na urządzeniu.
- Po instalacji należy zezwolić na powiadomienia. W HyperOS warto również włączyć autostart i ustawić brak ograniczeń baterii dla Zielnika.
