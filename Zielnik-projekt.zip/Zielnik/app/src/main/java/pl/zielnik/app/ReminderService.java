package pl.zielnik.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ReminderService extends Service {
    private static final String CHANNEL = "zielnik_tasks";
    private static final int BASE_ID = 10000;
    private final Set<Integer> posted = new HashSet<>();

    static void requestSync(Context context) {
        Intent intent = new Intent(context, ReminderService.class);
        intent.setAction("SYNC");
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent); else context.startService(intent);
    }

    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        List<TaskStore.Task> tasks = TaskStore.get(this);
        NotificationManager manager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (tasks.isEmpty()) {
            cancelAllTaskNotifications(manager);
            posted.clear(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY;
        }
        TaskStore.Task first = tasks.get(0);
        int foregroundId = notificationId(first.id);
        Notification firstNotification = buildTaskNotification(first);
        if (Build.VERSION.SDK_INT >= 34) startForeground(foregroundId, firstNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(foregroundId, firstNotification);
        Set<Integer> now = new HashSet<>();
        for (TaskStore.Task task : tasks) {
            int id = notificationId(task.id); now.add(id);
            if (id != foregroundId) manager.notify(id, buildTaskNotification(task));
        }
        cancelStaleTaskNotifications(manager, now);
        posted.clear(); posted.addAll(now);
        return START_STICKY;
    }

    private void cancelAllTaskNotifications(NotificationManager manager) {
        if (Build.VERSION.SDK_INT >= 23) {
            for (android.service.notification.StatusBarNotification active : manager.getActiveNotifications()) {
                int id = active.getId();
                if (id >= BASE_ID && id < BASE_ID + 1000000) manager.cancel(id);
            }
        }
    }

    private void cancelStaleTaskNotifications(NotificationManager manager, Set<Integer> keep) {
        if (Build.VERSION.SDK_INT >= 23) {
            for (android.service.notification.StatusBarNotification active : manager.getActiveNotifications()) {
                int id = active.getId();
                if (id >= BASE_ID && id < BASE_ID + 1000000 && !keep.contains(id)) manager.cancel(id);
            }
        }
    }

    private int notificationId(long id) { return BASE_ID + (int)(id % 1000000L); }
    private Notification buildTaskNotification(TaskStore.Task task) {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, (int)task.id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        String content = task.description == null || task.description.trim().isEmpty() ? "Twoje przypomnienie czeka" : task.description;
        builder.setSmallIcon(pl.zielnik.app.R.drawable.ic_leaf)
                .setContentTitle(task.title)
                .setContentText(content)
                .setStyle(new Notification.BigTextStyle().bigText(content))
                .setContentIntent(pending)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setOngoing(true)
                .setAutoCancel(false)
                .setShowWhen(false)
                .setOnlyAlertOnce(true);
        return builder.build();
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Zadania Zielnika", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Trwałe powiadomienia dla aktywnych zadań");
            channel.setShowBadge(true);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
