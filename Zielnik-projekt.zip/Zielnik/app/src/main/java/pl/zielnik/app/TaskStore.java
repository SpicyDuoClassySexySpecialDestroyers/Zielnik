package pl.zielnik.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

final class TaskStore {
    static final String PREFS = "zielnik_data";
    static final String KEY_TASKS = "tasks";
    static final String KEY_NEXT_ID = "next_id";

    static final class Task {
        final long id;
        final String title;
        final String description;
        Task(long id, String title, String description) {
            this.id = id; this.title = title; this.description = description;
        }
    }

    static List<Task> get(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_TASKS, "[]");
        ArrayList<Task> result = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                result.add(new Task(obj.getLong("id"), obj.optString("title"), obj.optString("description")));
            }
        } catch (Exception ignored) { }
        return result;
    }

    static void save(Context context, List<Task> tasks) {
        JSONArray array = new JSONArray();
        try {
            for (Task task : tasks) {
                JSONObject obj = new JSONObject();
                obj.put("id", task.id); obj.put("title", task.title); obj.put("description", task.description);
                array.put(obj);
            }
        } catch (Exception ignored) { }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TASKS, array.toString()).apply();
    }

    static long nextId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long id = prefs.getLong(KEY_NEXT_ID, 1L);
        prefs.edit().putLong(KEY_NEXT_ID, id + 1L).apply();
        return id;
    }

    static void sync(Context context) {
        ReminderService.requestSync(context);
    }
}
