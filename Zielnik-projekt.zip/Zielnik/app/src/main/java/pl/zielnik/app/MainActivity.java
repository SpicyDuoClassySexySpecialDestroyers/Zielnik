package pl.zielnik.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_NOTIFICATIONS = 41;
    private final int green = Color.rgb(35, 134, 83);
    private final int ink = Color.rgb(37, 55, 43);
    private final int muted = Color.rgb(105, 124, 109);
    private final int canvas = Color.rgb(245, 248, 244);
    private LinearLayout list;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(234,245,236));
        getWindow().setNavigationBarColor(Color.rgb(234,245,236));
        if (Build.VERSION.SDK_INT >= 23) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        requestNotificationPermission();
        buildScreen();
        TaskStore.sync(this);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(canvas);
        root.setPadding(dp(22), dp(24), dp(22), dp(18));
        TextView eyebrow = text("TWÓJ OSOBISTY PRZYPOMINACZ", 11, muted, true);
        root.addView(eyebrow);
        TextView title = text("Zielnik", 34, ink, true); title.setPadding(0, dp(3), 0, 0); root.addView(title);
        TextView subtitle = text("Małe kroki też prowadzą do celu.", 14, muted, false); subtitle.setPadding(0, 0, 0, dp(20)); root.addView(subtitle);

        Button add = new Button(this); add.setText("＋  Dodaj zadanie"); add.setTextColor(Color.WHITE); add.setTextSize(15); add.setAllCaps(false); add.setTypeface(null, Typeface.BOLD); add.setBackground(round(green, 16));
        root.addView(add, new LinearLayout.LayoutParams(-1, dp(52))); add.setOnClickListener(v -> showEditor(null));

        TextView section = text("Twoje zadania", 19, ink, true); section.setPadding(0, dp(25), 0, dp(10)); root.addView(section);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView footer = text("Przytrzymaj kartę, aby ją edytować lub usunąć.", 12, muted, false); footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(12), 0, 0); root.addView(footer);
        setContentView(root); renderTasks();
    }

    private void renderTasks() {
        list.removeAllViews(); List<TaskStore.Task> tasks = TaskStore.get(this);
        if (tasks.isEmpty()) {
            TextView empty = text("Na razie jest tu spokojnie 🌱\nDodaj pierwsze zadanie.", 15, muted, false);
            empty.setGravity(Gravity.CENTER); empty.setPadding(dp(12), dp(42), dp(12), dp(42)); list.addView(empty); return;
        }
        for (TaskStore.Task task : tasks) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(17), dp(15), dp(17), dp(15)); card.setBackground(round(Color.WHITE, 18));
            TextView label = text("●  PRZYPOMNIENIE", 10, green, true); card.addView(label);
            TextView heading = text(task.title, 17, ink, true); heading.setPadding(0, dp(7), 0, 0); card.addView(heading);
            if (!task.description.trim().isEmpty()) { TextView desc = text(task.description, 13, muted, false); desc.setPadding(0, dp(4), 0, 0); card.addView(desc); }
            TextView done = text("✓  Oznacz jako wykonane", 12, green, true); done.setPadding(0, dp(12), 0, 0); card.addView(done);
            done.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Oznaczyć jako wykonane?").setMessage("Powiadomienie tego zadania zostanie usunięte.").setNegativeButton("Wróć", null).setPositiveButton("Wykonane", (d,w) -> removeTask(task.id)).show());
            card.setOnLongClickListener(v -> { showActions(task); return true; });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(11); list.addView(card, lp);
        }
    }

    private void showActions(TaskStore.Task task) {
        String[] actions = {"Edytuj", "Usuń"};
        new AlertDialog.Builder(this).setTitle(task.title).setItems(actions, (dialog, which) -> {
            if (which == 0) showEditor(task);
            else new AlertDialog.Builder(this).setTitle("Usunąć zadanie?").setMessage("„" + task.title + "” zostanie usunięte z Zielnika i z panelu powiadomień.").setNegativeButton("Anuluj", null).setPositiveButton("Usuń", (d,w) -> removeTask(task.id)).show();
        }).show();
    }

    private void showEditor(TaskStore.Task existing) {
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(20), dp(8), dp(20), 0);
        EditText title = new EditText(this); title.setSingleLine(true); title.setHint("Np. Zadzwonić do Oli"); title.setTextSize(16); title.setHintTextColor(muted); title.setText(existing == null ? "" : existing.title); form.addView(title);
        EditText description = new EditText(this); description.setHint("Dodatkowy opis (opcjonalnie)"); description.setTextSize(14); description.setMinLines(2); description.setGravity(Gravity.TOP); description.setHintTextColor(muted); description.setText(existing == null ? "" : existing.description); form.addView(description);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(existing == null ? "Dodaj zadanie" : "Edytuj zadanie").setView(form).setNegativeButton("Anuluj", null).setPositiveButton(existing == null ? "Dodaj" : "Zapisz", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
            String t = title.getText().toString().trim();
            if (t.isEmpty()) { title.setError("Wpisz nazwę zadania"); return; }
            List<TaskStore.Task> tasks = new ArrayList<>(TaskStore.get(this));
            if (existing == null) tasks.add(new TaskStore.Task(TaskStore.nextId(this), t, description.getText().toString().trim()));
            else { for (int i=0;i<tasks.size();i++) if (tasks.get(i).id == existing.id) tasks.set(i, new TaskStore.Task(existing.id, t, description.getText().toString().trim())); }
            TaskStore.save(this, tasks); renderTasks(); TaskStore.sync(this); dialog.dismiss();
        }));
        dialog.show();
    }

    private void removeTask(long id) {
        List<TaskStore.Task> tasks = new ArrayList<>(TaskStore.get(this));
        for (int i=tasks.size()-1;i>=0;i--) if (tasks.get(i).id == id) tasks.remove(i);
        TaskStore.save(this, tasks); renderTasks(); TaskStore.sync(this);
    }

    private TextView text(String value, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(null, Typeface.BOLD); return t; }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
