package pl.zielnik.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.List;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        List<TaskStore.Task> tasks = TaskStore.get(context);
        if (!tasks.isEmpty()) ReminderService.requestSync(context);
    }
}
